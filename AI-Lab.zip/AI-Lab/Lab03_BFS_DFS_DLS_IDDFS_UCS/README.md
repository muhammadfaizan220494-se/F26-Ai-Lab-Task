# Lab 03 - Uninformed Search

BFS and DFS traces, Depth-Limited Search, Iterative Deepening DFS, Uniform-Cost Search on weighted graphs, plus edge cases (cycles, unreachable goals).

- `Lab03.ipynb` / `Lab03.py`: code
- `Lab03_Report.docx`: report

Run: `python Lab03.py`
