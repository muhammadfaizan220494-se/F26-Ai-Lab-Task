# AI-Lab

University AI lab tasks (Python).

| Lab | Topic |
|-----|-------|
| Lab01 | Symbolic rules vs probability threshold |
| Lab02 | Reflex, stateful and hysteresis agents |
| Lab03 | BFS, DFS, DLS, IDDFS, UCS |
| Lab04 | A* search and heuristics |

Each folder has the notebook (`.ipynb`), plain Python (`.py`), a report (`.docx`) and a README.
