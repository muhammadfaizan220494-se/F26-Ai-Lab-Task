# Lab 02 - Reflex and Stateful Agents

Classroom temperature agent: simple reflex agent, stateful agent (sends command only on mode change), and hysteresis agent to handle noisy readings.

- `Lab02.ipynb` / `Lab02.py`: code
- `Lab02_Report.docx`: report

Run: `python Lab02.py`
