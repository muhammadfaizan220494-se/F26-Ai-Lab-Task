# Lab 01 - Symbolic Rules vs Probability Threshold

Compares a rule-based (symbolic) decision with a probability-threshold decision, and extends it with a transparent scholarship rule checker.

- `Lab01.ipynb` / `Lab01.py`: code
- `Lab01_Report.docx`: report

Run: `python Lab01.py`
