def symbolic(score, complete):
    return "Review" if complete and score >= 70 else "Hold"

def threshold(probability):
    return "Review" if probability >= 0.70 else "Hold"

print("CASE STUDY: Original rule-based vs probability-threshold comparison")
cases = [
    ("complete_high", 82, True, 0.81),
    ("complete_low", 68, True, 0.74),
    ("incomplete_high", 91, False, 0.88),
    ("boundary", 70, True, 0.70),
]

print("case | score | complete | probability | symbolic | threshold | disagreement")
for name, score, complete, probability in cases:
    a = symbolic(score, complete)
    b = threshold(probability)
    print(name, score, complete, probability, a, b, a != b, sep=" | ")

print("\nCASE STUDY: Extended transparent rule checker")
def scholarship_checker(score, documents_complete, attendance, recommendation):
    if score < 70:
        return "Hold"
    if not documents_complete:
        return "Hold"
    if attendance < 75:
        return "Hold"
    if not recommendation:
        return "Hold"
    return "Review"

extended_cases = [
    ("Pass", 80, True, 85, True, "Review"),
    ("Attendance failure", 80, True, 70, True, "Hold"),
    ("Recommendation failure", 80, True, 85, False, "Hold"),
    ("Threshold boundary", 70, True, 75, True, "Review"),
]
print("Case | Input | Expected | Actual | Result | Reason")
for name, score, docs, attendance, rec, expected in extended_cases:
    actual = scholarship_checker(score, docs, attendance, rec)
    reasons = {
        "Pass": "All conditions pass",
        "Attendance failure": "Attendance is below 75%",
        "Recommendation failure": "Recommendation letter is missing",
        "Threshold boundary": "Score 70 and attendance 75 meet the limits",
    }
    inputs = (score, docs, attendance, rec)
    result = "PASS" if actual == expected else "FAIL"
    print(f"{name} | {inputs} | {expected} | {actual} | {result} | {reasons[name]}")
