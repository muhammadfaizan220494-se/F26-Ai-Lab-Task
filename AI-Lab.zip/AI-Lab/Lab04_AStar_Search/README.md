# Lab 04 - A* Search

A* implementation with heuristic audit (admissible and consistent), UCS comparison (h = 0), and experiments with overestimated heuristics.

- `Lab04.ipynb` / `Lab04.py`: code
- `Lab04_Report.docx`: report

Run: `python Lab04.py`
